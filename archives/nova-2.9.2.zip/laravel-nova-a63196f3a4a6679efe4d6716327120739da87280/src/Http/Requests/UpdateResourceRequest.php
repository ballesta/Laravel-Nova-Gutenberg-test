<?php

namespace Laravel\Nova\Http\Requests;

class UpdateResourceRequest extends NovaRequest
{
    //
}
